interface OldDevice {
    void switchOn();
    void switchOff();
}
