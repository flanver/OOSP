public interface Observer {
    void update(String activity);
}
