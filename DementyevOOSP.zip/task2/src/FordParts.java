class FordEngine implements Engine {
    public String getType() {
        return "Ford Engine";
    }
}
class FordWheel implements Wheel {
    public String getSize() {
        return "18 inch Ford Wheel";
    }
}

class FordBody implements Body {
    public String getShape() {
        return "SUV Ford Body";
    }
}
