public interface Body {
    String getShape();
}
