public interface Engine {
    String getType();
}
