public interface Wheel {
    String getSize();
}
