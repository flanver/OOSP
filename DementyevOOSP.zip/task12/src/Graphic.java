public interface Graphic {
    void draw();
}
