public class AudioSystem {
    public void turnOn() {
        System.out.println("Аудиосистема включена.");
    }

    public void turnOff() {
        System.out.println("Аудиосистема выключена.");
    }

    public void setVolume(int volume) {
        System.out.println("Громкость установлена на " + volume + ".");
    }
}
