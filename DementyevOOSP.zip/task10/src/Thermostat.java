public class Thermostat {
    public void setTemperature(int temperature) {
        System.out.println("Температура установлена на " + temperature + " градусов.");
    }
}
