public interface Shape {
    void draw();    // Метод для отрисовки фигуры
    Shape clone();  // Метод клонирования
}
